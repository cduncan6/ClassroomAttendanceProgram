10/16/2016 Updates
Author: Jeff W.
##################
- Updated "My Classes"
	- Added a "Select" button
	- Added tool text above "Upload button"
	- Fixxed CSS for elements from "My Classes'

- Updated "Take Attendance"
	- Deleted "Date Box" drop down

10/18/2016
Author: Jeff W.
##################
	- PHP
	- Login
	- Logout
	- Session 

11/9/2016
##################
-HTML
	- Added headers for <li> tags on sidebar menu
	- Created "Getting Started" and "Tutorial" sidebar option
	- Import seperated from My Classes into its own sidebar option named "Import Classes"
	- "Home" button back to top nav bar

-CSS
	- Adjusted sidebar width %
	- Adjusted content title header width %
	- Fixed some padding for various elements
11/15/2016
Author: Trey
- finished delete and cancel tabs

11/16/2016
Author Jeff W.
####################
	- Changed sidebar html and css
11/17/2016
Author: Jeff W.
######################
	- "Upload Classes" tab 
		- Added Select drop down
		- Added Choose file option
		- Added three time intervals (Start, Tardy, End)

11/28/2016
Author: Jeff W.
####################
	- Updated Login page
	- Updated CSS on buttons on dashboard
	- Created "Change Password" forms
	- Contact Us forms

11/30/2016
Author: Jeff W.
####################
	- Created About.html
	- Updated About tab
	- Updated "Choose File" button css
	- Updated help tip bubbles
	- Deleted Remember Me! box