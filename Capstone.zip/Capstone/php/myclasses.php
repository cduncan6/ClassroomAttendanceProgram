<!--
Last edited on: November 23rd, 2016
Author: Mario Esho
-->
<html>
<head>
<link href="/Capstone/css/dashboard.css" rel="stylesheet">
<link href="/Capstone/css/myclasses.css" rel="stylesheet">
</head>
<body>
<?php

/*******************************************************
*
*	Database connection
*
********************************************************/
session_start();
$connection = new mysqli('localhost', 'root', '', 'mydb');
update($connection); //update attendence table
if ($connection->connect_error){
  die("Connection Error: " . $connection->connect_error);
}

/*******************************************************
*
*	Deletes class roster from studentclass table
*
********************************************************/
if(isset($_POST['deletesubmit'])){
	$selected = $_POST['deletesel'];
	$Teach_Rocket = $_SESSION['login_user'];

	$query = "SELECT idClass FROM class WHERE Name LIKE '%".$selected."%' AND TeacherRocketNum = '$Teach_Rocket'";

	$result = mysqli_query($connection, $query) or die("Connection Error: " . $connection->connect_error);

	while ($row = $result->fetch_assoc()) {$classid = $row['idClass'];}

	mysqli_query($connection, "DELETE FROM studentclass WHERE idClass = '$classid'");

	$success2 = "Deleted ".$selected." student roster.";
}

/*******************************************************
*
*	Prints Table for attendence record in My Classes tab
*
********************************************************/
if(isset($_POST['classsubmit'])){
	$selected = $_POST['classsel'];
	$searchdate = $_POST['datesel'];
	$_SESSION['prev'] = $_SERVER["HTTP_REFERER"];

	if(!$searchdate){
		$query= "SELECT at.DeviceNum device, at.idClass, at.Date_ as date, DATE_FORMAT(at.Time_, '%I:%i %p') as time, at.RocketNum as rocket, at.Image as image, at.Comments as comments, at.Status as status, c.idClass, c.Name, c.Location_One, st.Name as name, st.RocketNum, s.idClass, s.RocketNum FROM attendance at
					INNER JOIN class c ON at.idClass = c.idClass
					INNER JOIN studentclass s ON c.idClass = s.idClass
					INNER JOIN student st ON s.RocketNum = st.RocketNum AND s.RocketNum = at.RocketNum
					WHERE c.Name LIKE '%".$selected."%'
					ORDER BY at.Date_, at.Time_";
		$_SESSION['query'] = $query;
	}
	else{
		$query= "SELECT at.DeviceNum device, at.idClass, at.Date_ as date, DATE_FORMAT(at.Time_, '%I:%i %p') as time, at.RocketNum as rocket, at.Image as image, at.Comments as comments, at.Status as status, c.idClass, c.Name, c.Location_One, st.Name as name, st.RocketNum, s.idClass, s.RocketNum FROM attendance at
					INNER JOIN class c ON at.idClass = c.idClass
					INNER JOIN studentclass s ON c.idClass = s.idClass
					INNER JOIN student st ON s.RocketNum = st.RocketNum AND s.RocketNum = at.RocketNum
					WHERE c.Name LIKE '%".$selected."%' AND at.Date_ = '$searchdate'
					ORDER BY at.Date_, at.Time_";
		$_SESSION['query'] = $query;
	}

	$result = mysqli_query($connection, $query) or die("Connection Error: " . $connection->connect_error);
	$rows = mysqli_num_rows($result);
	echo "<h2 class='sub-header'>".$selected."</h2>";
	if($rows == 0){echo "No results found.";}
	else{table($result);}
}


/*******************************************************
*
*	Updates attendance table to canceled class status
*
********************************************************/
if(isset($_POST['cancelsubmit'])){
	$Teach_Rocket = $_SESSION['login_user'];
	$selected = $_POST['cancelsel'];
	$date = $_POST['canceldate'];

	if($date == NULL){$success = "Please enter a date to cancel class for ".$selected;}
	else{
		$query= "SELECT c.idClass as classid, c.Name, c.Location_One, s.idClass, s.RocketNum as rocket, d.DeviceID as device, d.Location FROM class c
					INNER JOIN studentclass s ON c.idClass = s.idClass
					INNER JOIN device d ON c.Location_One = d.Location
					WHERE TeacherRocketNum = '$Teach_Rocket' AND c.Name LIKE '%".$selected."%'";

		$result = mysqli_query($connection, $query) or die("Connection Error: " . $connection->connect_error);

		while ($row = $result->fetch_assoc()){
			$query2 = "INSERT INTO `attendance`(`DeviceNum`, `Date_`, `RocketNum`, `idClass`, `Status`) VALUES ('".$row['device']."','$date','".$row['rocket']."','".$row['classid']."','Class Canceled')";
			mysqli_query($connection, $query2);
		}

		$rows = mysqli_affected_rows($connection);
		if($rows == 0){$success = "There is not student roster in ".$selected;}
		else{$success = "Canceled ".$selected." on ".$date;}
	}
}

/*******************************************************
*
*	Prints Table for search in Search tab
*
********************************************************/
if(isset($_POST['searchsubmit'])){

	$classname = $_POST['searchsel'];
	$searchterm = trim($_POST['searchterm']);
	$searchdate = $_POST['searchdate'];
	$_SESSION['prev'] = $_SERVER["HTTP_REFERER"];

	if (!$searchterm) {
	echo 'You have not entered search details. Please go back and try again.';
	exit;
	}

	if(!$searchdate){
		$query= "SELECT at.DeviceNum device, at.idClass, at.Date_ as date, DATE_FORMAT(at.Time_, '%I:%i %p') as time, at.RocketNum as rocket, at.Image as image, at.Comments as comments, at.Status as status, c.idClass, c.Name, c.Location_One, st.Name as name, st.RocketNum, s.idClass, s.RocketNum FROM attendance at
					INNER JOIN class c ON at.idClass = c.idClass
					INNER JOIN studentclass s ON c.idClass = s.idClass
					INNER JOIN student st ON s.RocketNum = st.RocketNum AND s.RocketNum = at.RocketNum
					WHERE c.Name LIKE '%".$classname."%' AND (st.Name LIKE '%".$searchterm."%' OR at.RocketNum LIKE '%".$searchterm."%')
					ORDER BY at.Date_, at.Time_";
		$_SESSION['query'] = $query;
	}
	else{
		$query= "SELECT at.DeviceNum device, at.idClass, at.Date_ as date, DATE_FORMAT(at.Time_, '%I:%i %p') as time, at.RocketNum as rocket, at.Image as image, at.Comments as comments, at.Status as status, c.idClass, c.Name, c.Location_One, st.Name as name, st.RocketNum, s.idClass, s.RocketNum FROM attendance at
					INNER JOIN class c ON at.idClass = c.idClass
					INNER JOIN studentclass s ON c.idClass = s.idClass
					INNER JOIN student st ON s.RocketNum = st.RocketNum AND s.RocketNum = at.RocketNum
					WHERE c.Name LIKE '%".$classname."%' AND at.Date_ = '$searchdate' AND (st.Name LIKE '%".$searchterm."%' OR at.RocketNum LIKE '%".$searchterm."%')
					ORDER BY at.Date_, at.Time_";
		$_SESSION['query'] = $query;
	}

	$result = mysqli_query($connection, $query) or die("Connection Error: " . $connection->connect_error);
	$rows = mysqli_num_rows($result);
	echo "<h2 class='sub-header'>".$classname."</h2>";
	if($rows == 0){ echo "No results found.";}
	else{table($result);}
}

/*******************************************************
*
*	Manually updates attendance table from MyClasses tab
*
********************************************************/
if (isset($_POST['attensubmit'])) {

	//check if the user chose a file
	if(empty($_FILES['filename']['name'])){$error = "No File Chosen. Please Try Again.";}
	else{
		$handle = fopen($_FILES['filename']['tmp_name'], "r"); //opens the file

		//loop to insert into attendance table and give a message if completed or not.
		while(($data = fgetcsv($handle, ",")) !== FALSE){
			if($data[0] === NULL){$error = "File is Empty. Please use a different file.";}
			elseif(count($data) != 4){$error = "Incorrect file or incorrect number of fields needed";}

			if(!isset($error) and $data[0] != FALSE){
				$date = date('Y-m-d', strtotime($data[1]));

				$query2 =  "INSERT INTO `attendance`(`DeviceNum`, `Date_`, `Time_`, `RocketNum`)
								SELECT '$data[0]','$date','$data[2]','$data[3]' FROM DUAL
								WHERE NOT EXISTS (SELECT * FROM `attendance`
      												WHERE DeviceNum='$data[0]' AND Date_='$date' AND Time_='$data[2]' AND RocketNum='$data[3]')
								LIMIT 1";

				$result = mysqli_query($connection, $query2) or die("Connection Error" . $connection->connect_error);
				$rows = mysqli_affected_rows($connection);
				if($rows == 0){$success = "Already have uploaded these records.";}
				else{$success = "Uploaded attendence records successfully.";}
			}
		}

		fclose($handle); //closes the file being open
	}
}


/*******************************************************
*
*	Uploads class roster in studentclass and student table in Upload Classes tab
*
********************************************************/
if (isset($_POST['uploadsubmit'])) {
	$Teach_Rocket = $_SESSION['login_user'];
	$selected = $_POST['uploadsel']; //selected class from drop down
	$tardy_sel = $_POST['tardytime'];

	//query to get device and class id
	$query= "SELECT c.idClass as classid, c.Name as classname, c.Location_One, c.Tardy_Time as tardy, d.DeviceID as device, d.Location FROM class c
				INNER JOIN device d ON c.Location_One = d.Location
				WHERE TeacherRocketNum = '$Teach_Rocket' AND c.Name LIKE '%".$selected."%'";
	$result = mysqli_query($connection, $query) or die("Connection Error: " . $connection->connect_error);
	while($row = $result->fetch_assoc()){
		$classid = $row['classid'];
		$classname = $row['classname'];
		$tardy_time = $row['tardy'];
	}

	if($tardy_sel != NULL){
		$tardy_sel = date("H:i:s", strtotime("$tardy_sel +1 minute"));
		$query4 = "UPDATE `class` SET `Tardy_Time`='$tardy_sel' WHERE idClass = '$classid'";
		mysqli_query($connection, $query4) or die("Connection Error" . $connection->connect_error);
		$tardy = "Tardy has been updated.</br>";
	}
	elseif($tardy_time == NULL){$tardy = "Please enter a tardy time for ".$classname.".</br>";}

	//check if the user chose a file
	if(empty($_FILES['filename']['name'])){$error = "No File Chosen.";}
	else{
		$handle = fopen($_FILES['filename']['tmp_name'], "r"); //opens the file

		//loop to insert into attendance table and give a message if completed or not.
		while(($data = fgetcsv($handle, ",")) !== FALSE){
			if($data[0] === NULL){$error = "File is Empty. Please use a different file.";}
			elseif(count($data) != 2){$error = "Incorrect file or incorrect number of fields needed.";}

			if(!isset($error) and $data[0] != FALSE){
				$query2 =  "INSERT INTO `studentclass`(`RocketNum`, `idClass`)
								SELECT '$data[0]', '$classid' FROM DUAL
								WHERE NOT EXISTS (SELECT * FROM `studentclass`
      												WHERE RocketNum='$data[0]' AND idClass='$classid')
								LIMIT 1 ";

				$query3 =  "INSERT INTO `student`(`RocketNum`, `Name`)
								SELECT '$data[0]', '$data[1]' FROM DUAL
								WHERE NOT EXISTS (SELECT * FROM `student`
      												WHERE RocketNum='$data[0]' AND Name='$data[1]')
								LIMIT 1 ";

				mysqli_query($connection, $query3) or die("Connection Error");
				mysqli_query($connection, $query2) or die("Connection Error" . $connection->connect_error);

				$rows = mysqli_affected_rows($connection);
				if($rows == 0){$success1 = "Records already exist for this class.";}
				else{$success1 = "Uploaded class roster successfully.";}
			}
		}

		fclose($handle); //closes the file being open
	}
}

/*******************************************************
*
*	Function ~ Updates attendance table with idClass and status
*
********************************************************/
function update($conn){

	$Teach_Rocket = $_SESSION['login_user'];

	//class table query
	$sql_c = "SELECT idClass, Days, Start_Time, End_Time, Tardy_Time FROM class WHERE TeacherRocketNum = '$Teach_Rocket' ORDER BY End_Time ASC";
	$result_c = mysqli_query($conn, $sql_c) or die($conn->error);

	//while loop into class table
	while ($row_c = $result_c->fetch_assoc()){
		$days = $row_c['Days'];
		$start = $row_c['Start_Time'];
		$end = $row_c['End_Time'];
		$tardy = $row_c['Tardy_Time'];
		$class_id = $row_c['idClass'];
		$day_arr = array();

		//checks what days the classes occur on and gives it the actual day
		for($i = 0; $i < strlen($days); $i++){
			switch($days[$i]){
				case "M":
					array_push($day_arr, "Monday");
					break;
				case "T":
					if($days[$i + 1] != "H"){
						array_push($day_arr, "Tuesday");
					}
					else{
						array_push($day_arr, "Thursday");
					}
					break;
				case "W":
					array_push($day_arr, "Wednesday");
					break;
				case "F":
					array_push($day_arr, "Friday");
					break;
				default:
					break;
			}
		}

		//attendance table query
		$sql_at = "SELECT at.DeviceNum as device, DATE_FORMAT(at.Date_, '%W') as day, at.Date_ as date, at.Time_ as time, at.RocketNum as rocket, at.idClass, at.Status as status, c.idClass, c.Location_One, d.DeviceID, d.Location, st.RocketNum, s.idClass, s.RocketNum FROM attendance at
					INNER JOIN device d ON at.DeviceNum = d.DeviceID
					INNER JOIN class c ON d.Location = c.Location_One
					INNER JOIN studentclass s ON c.idClass = s.idClass
					INNER JOIN student st ON s.RocketNum = st.RocketNum AND s.RocketNum = at.RocketNum
					WHERE TeacherRocketNum = '$Teach_Rocket'
					ORDER BY at.Date_, at.Time_ ASC";
		$result_at = mysqli_query($conn, $sql_at) or die($conn->error);

		//while loop into attendance table while looping through class table
		while ($row_at = $result_at->fetch_assoc()){
			$student_time = $row_at['time'];
			$status = $row_at['status'];
			$day = $row_at['day'];
			$date = $row_at['date'];
			$device = $row_at['device'];
			$rocket = $row_at['rocket'];

			//looping through the class days to match with the swipe day
			for($i = 0; $i < count($day_arr); $i++){
				if($day === $day_arr[$i]){
					//checks to see if the status has already been set and if tardy has been set
					if($tardy != NULL and $status == NULL){
						/*checks to see if the swipe time occured before the end of class time
						  this works because the swipes are ordered by date and time so it only
						  needs to check if the swipe is before the end of class time*/
						if($student_time < $end){
							//checks to see if the swipe time occured before the tardy time
							if($student_time < $tardy){
								mysqli_query($conn, "UPDATE attendance SET Status = 'On Time', idClass = '$class_id' WHERE DeviceNum = '$device' AND Date_ = '$date' AND Time_ = '$student_time' AND RocketNum = '$rocket'");
							}
							//else if not then the swipe is tardy
							else{
								mysqli_query($conn, "UPDATE attendance SET Status = 'Tardy', idClass = '$class_id' WHERE DeviceNum = '$device' AND Date_ = '$date' AND Time_ = '$student_time' AND RocketNum = '$rocket'");
							}
						}
					}
				}
			}
		}
	}
}

/*******************************************************
*
*	Function ~ Drop Down list for class selection: used in My Classes and Search tab
*
********************************************************/
function Class1($conn){

	$Teach_Rocket = $_SESSION['login_user'];

	$sql = "SELECT Name FROM class WHERE TeacherRocketNum = '$Teach_Rocket'";
	$result = mysqli_query($conn, $sql) or die($conn->error);

	while ($row = $result->fetch_assoc()){
		echo "<option value = '".$row['Name']."'>" . $row['Name'] . "</option>";
	}
}

/*******************************************************
*
*	Updates table if changes are made to status and comment
*
********************************************************/
if(isset($_POST['updatetable'])){
	$rows = 0;
	for($i=0;$i < $_SESSION['edits']; $i++){
		$status = $_POST['status_'.$i];
		$comment = $_POST['comment_'.$i];
		$device = $_POST['device_'.$i];
		$date = $_POST['date_'.$i];
		$time = $_POST['time_'.$i];
		$rocket = $_POST['rocket_'.$i];

		//updates status and comment
		if($time != NULL){
			mysqli_query($connection, "UPDATE attendance SET Status = '$status', Comments = '$comment' WHERE DeviceNum = '$device' AND Date_ = '$date' AND DATE_FORMAT(Time_, '%I:%i %p') = '$time' AND RocketNum = '$rocket'");
		}
		else{
			mysqli_query($connection, "UPDATE attendance SET Status = '$status', Comments = '$comment' WHERE DeviceNum = '$device' AND Date_ = '$date' AND RocketNum = '$rocket'");
		}
		$rows += mysqli_affected_rows($connection);
	}

	$query = $_SESSION['query'];
	$result = mysqli_query($connection, $query) or die("Connection Error" . $connection->connect_error);

	if ($rows == 0){
		$_SESSION['success'] = "Did not make any changes.";
	}
	else{
		$_SESSION['success'] = "Successfully made changes.";
	}

	table($result);
}

/*******************************************************
*
*	Function ~ Table format: used in My Classes and Search tab
*
********************************************************/
function table($result){ ?>
<form method="post" enctype="multipart/form-data">
<table class='table'>
	<thead>
	<tr>
		<th>Student Name</th>
		<th>Rocket Number</th>
		<th>Date</th>
		<th>Time</th>
		<th>Status</th>
		<th>Comments</th>
		<th>Image</th>
	</tr>
	</thead>
	<tbody>
		<?php
		$num = 0;
		while ($row = $result->fetch_assoc()) {
			echo "<tr>";
			echo "<td>".$row['name']."</td>";
			echo "<td>".$row['rocket']."</td>";
			echo "<td>".$row['date']."</td>";
			echo "<td>".$row['time']."</td>";
			echo "<td><input type='text' name='status_{$num}' value='{$row['status']}' style='border: none'/></td>";
			echo "<td><input type='text' name='comment_{$num}' value='{$row['comments']}' style='border: none'/></td>";
			echo "<td><img id='myImg_{$num}' src='data:image/jpeg;base64,".base64_encode( $row['image'] )."' alt='".$row['name']."' width='25' height='25'/></td>";?>
			<div id="myModal" class="modal">
			  <span class="close" onclick="document.getElementById('myModal').style.display='none'">&times;</span>
			  <img class="modal-content" id="img01">
			  <div id="caption"></div>
			</div>
			<style>
			/* Style the Image Used to Trigger the Modal */
			#myImg_<?php echo $num;?> {
				 border-radius: 5px;
				 cursor: pointer;
				 transition: 0.3s;
			}

			#myImg_<?php echo $num;?>:hover {opacity: 0.7;}
			</style>
			<script>
			var modal = document.getElementById('myModal');
			var pic = "myImg_" + <?php echo $num; ?>;
			var img = document.getElementById(pic);
			var modalImg = document.getElementById("img01");
			var captionText = document.getElementById("caption");
			img.onclick = function(){
				 modal.style.display = "block";
				 modalImg.src = this.src;
				 captionText.innerHTML = this.alt;
			}
			var span = document.getElementsByClassName("close")[0];
			span.onclick = function() { 
				 modal.style.display = "none";
			}
			</script>
<?php		echo "</tr>";
			echo "<input type='hidden' name='device_{$num}' value='{$row['device']}'/>";
			echo "<input type='hidden' name='date_{$num}' value='{$row['date']}'/>";
			echo "<input type='hidden' name='time_{$num}' value='{$row['time']}'/>";
			echo "<input type='hidden' name='rocket_{$num}' value='{$row['rocket']}'/>";
			$num += 1;
		}
		$_SESSION['edits'] = $num;
		echo "</tbody>";
		echo "</table>";
		echo "</br></br>";
		echo "<input style='cursor: pointer' type='submit' name='updatetable' class='button' value='Submit Changes' onclick='return confirm(\"Are you sure you want to submit these updates?\")'/>";
		echo "</form>";
		echo "<a class='button' href=".$_SESSION['prev'].">Go Back</a>";
		if(isset($_SESSION['success'])){echo $_SESSION['success']."</br></br>";}
		unset($_SESSION['success']);
}

?>
</body>
</html>
