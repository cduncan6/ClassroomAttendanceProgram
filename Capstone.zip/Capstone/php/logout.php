<?php
session_start();
if(session_destroy()) // Destroying All Sessions
{
header("Location: /Capstone/index.html"); // Redirecting To Home Page
}
?>
