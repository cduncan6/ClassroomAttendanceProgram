<html>
<head>
<title>Classroom Attendance Program Database</title>
</head>
<link href="/Capstone/main.css" type="text/css" rel="stylesheet" />
<body>
  <?php
  session_start(); // Starting Session
  $error='';
  if (isset($_POST['submit'])) {
  if (empty($_POST['username']) || empty($_POST['password'])) {
  echo 'Username or Password is invalid';
  }
  else
  {
  // Define $username and $password
  $username=$_POST['username'];
  $password=$_POST['password'];
  // Establishing Connection with Server by passing server_name, user_id and password as a parameter
  $connection = new mysqli('localhost', 'root', '', 'mydb');
  if (!$connection){
    mysqli_error($connection);
  }
  // To protect MySQL injection for Security purpose
  $username = stripslashes($username);
  $password = stripslashes($password);
  $username = mysqli_real_escape_string($connection, $username);
  $password = mysqli_real_escape_string($connection, $password);
  $passwordsha = sha1($password);
  // SQL query to fetch information of registerd users and finds user match.
  $sql = "SELECT * from teacher where RocketNum='$username' and Password='$passwordsha'";
  $result= mysqli_query($connection, $sql);
  if (!$result){
    die(mysqli_error($connection));
  }
  $rows = mysqli_num_rows($result);

  if ($rows == 1) {
  $_SESSION['login_user']=$username; // Initializing Session
  header("location: /Capstone/main.html"); // Redirecting To Other Page
  } else {
  echo 'Username or Password is invalid ' . $passwordsha;
  }
  mysqli_close($connection); // Closing Connection
  }
  }
  ?>
 </body>
 </html>
