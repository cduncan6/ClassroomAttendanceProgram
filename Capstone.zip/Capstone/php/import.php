
 <?php
    //Last edited on October 18th, 2016
    //Author: Cody Duncan
    //connect to the database
    $connection = new mysqli('localhost', 'root', '', 'mydb');
    $mytableinsert1 = $_POST['mytableinsert1']; //my table insert is from the Import.html page.
    if (isset($_POST['submit'])) {
  	    if (is_uploaded_file($_FILES['filename']['tmp_name'])) {
  	        echo "<h1>" . "File ". $_FILES['filename']['name'] ." uploaded successfully." . "</h1>"; //displays success message.
  	        echo "<h2>Displaying contents:</h2>"; //displays part of the uploaded data.
  	        readfile($_FILES['filename']['tmp_name']);
            echo "<br /><br /><h3></h3>"; //Can be changed or removed.
}
  	    $handle = fopen($_FILES['filename']['tmp_name'], "r");
  	    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
  	        $import="INSERT into studentclass (idClass, RocketNum) //imports the data from the //file.
            values('$data[0]','$data[1])";
  	        mysqli_query($connection, $import) or die(mysqli_error($connection));
  	    }
  	    fclose($handle);
  	}else {
  	}
    ?>
