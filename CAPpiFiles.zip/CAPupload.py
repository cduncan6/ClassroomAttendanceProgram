#!/user/bin/python
from time import gmtime, strftime
import RPi.GPIO as GPIO
import time
import os, sys
import os, glob
import shutil
import datetime
import pymysql

def tempfilename():#Changes the file name of the students input to a temp file
    for filename in os.listdir("."):
        if filename.startswith("CAP_TEMP"):#checks if a temp file exists
            os.remove("/home/pi/CAP/CAP_TEMP.txt")#removes the file
            exist = False
        elif filename.startswith("CAPid"):
            os.rename(filename, filename.replace("CAPid", "CAP_TEMP"))
            exist = True
        else:
            exist = False
    return exist;

def dirchange():#this is used to change the directories for the pictures for upload
    basedir = "/home/pi/CAP"
    for fn in os.listdir(basedir):
        if not os.path.isdir(os.path.join(basedir, fn)):
            continue # Not a directory
        
        if 'CAPTEMPpic' in fn:
            shutil.rmtree("/home/pi/CAP/CAPTEMPpic")
            #directory already exists and needs to be removed
            
        if 'CAPpic' in fn:
            #print ("The dir is: %s"%os.listdir(os.getcwd()))
            os.rename("CAPpic","CAPTEMPpic")
            #print ("Successfully renamed.")
            # listing directories after renaming "tutorialsdir"
            #print ("the dir is: %s" %os.listdir(os.getcwd()))

    return;

def sqlconvert(file):
    
    if file == True:
        origFile = '/home/pi/CAP/CAP_TEMP.txt'
        logFile = '/home/pi/CAP/CAPlog/Archive/log.txt'
        sqlFile = '/home/pi/CAP/CAPlog/Upload/sql.txt'
        storFile = '/home/pi/CAP/CAPlog/Storage/storfile'
        
        log = ' records were updated to the server: '
        lines = 0
        ctime = str(datetime.datetime.now())

        with open(origFile) as f:
            for line in f:
                count = -1
                while len(line) > 0:
                    count = count + 1

                    t = line.partition(",")

                    if count == 0 or count == 5:
                        rnumber = t[0]
                    if count == 1:
                        date = t[0]
                    if count == 2:
                        stime = t[0]
                    if count == 3:
                        device = t[0]
                    if count == 4:
                        image = t[0].rstrip('\n')
                        picbasedir = "/home/pi/CAP/CAPTEMPpic"
                        for pic in os.listdir(picbasedir):
                            if image in pic:
                                pichome = "/home/pi/CAP/CAPTEMPpic/" + image
                                picnew = "/home/pi/CAP/CAPlog/Pics/" + image
                                os.rename(pichome,picnew)
                        
                   
                    # Set string variable to non-partitioned part
                    line = t[2]
                
                tmp = rnumber + "," + date + "," + stime + "," + device + "," + image + "\n"
                print (tmp)
                #edit sql insert file
                appendFile = open(sqlFile, "a")
                appendFile.write(tmp)
                lines = lines + 1
            
            #edit log file        
            with open(logFile, "a") as appendLog:
                tmp2 = str(lines) + log + ctime + '\n'
                print(tmp2)
                appendLog.write(tmp2)

            #move attendace file to storage
            os.rename(origFile, storFile + ctime.replace(" ", "-").replace(".", ":").replace(":", "_")+ '.csv')
    return;

def databaseupload():
    sqlFile = '/home/pi/CAP/CAPlog/Upload/sql.txt'


    conn = pymysql.connect( host='192.168.1.1',
                            user='root',
                            password='capstone',
                            db='mydb',
                            charset='utf8mb4',
                            cursorclass=pymysql.cursors.DictCursor)

    try:
            with conn.cursor() as cursor:
                    with open(sqlFile) as f:
                            for line in f:
                                    t = line.split(",")
                                    basepic = '/home/pi/CAP/CAPlog/Pics/'
                                    image = t[4].rstrip('\n')
                                    for pic in os.listdir(basepic):
                                        if image in pic:
                                                pic_path = '/home/pi/CAP/CAPlog/Pics/' + image
                                                with open(pic_path, 'rb') as j:
                                                        photo = j.read()
                                                        j.close()
                                                query = "INSERT INTO Attendance (RocketNum, Date_, Time_, DeviceNum, Image) VALUES ('" + t[0] + "', '" + t[1] + "', '" + t[2] + "', " + t[3] + ", %s);"
                                                cursor.execute(query, photo)
                                                conn.commit()
                                                os.remove(pic_path)
                                        else:
                                                query = "INSERT INTO Attendance (RocketNum, Date_, Time_, DeviceNum) VALUES ('" + t[0] + "', '" + t[1] + "', '" + t[2] + "', " + t[3] + ");"
                                                cursor.execute(query)
                                                conn.commit()
            open(sqlFile, 'w')
                                    

    finally:
            conn.close()


GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
#sets the LED's ready for future functions
GPIO.setup(16,GPIO.OUT)
GPIO.setup(20,GPIO.OUT)
GPIO.setup(21,GPIO.OUT)

#test output for program running 

while True:
    GPIO.output(20,GPIO.LOW)
    GPIO.output(16,GPIO.LOW)
    GPIO.output(21,GPIO.HIGH)
    temp = tempfilename()
    dirchange()
    sqlconvert(temp)
    databaseupload()
    GPIO.output(21,GPIO.LOW)
    GPIO.output(20,GPIO.HIGH)
    #slq program start
    #slq program kill
    time.sleep(1200)


    
