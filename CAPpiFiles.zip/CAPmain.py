#!/user/bin/python
from time import gmtime, strftime
import RPi.GPIO as GPIO
import time
import os
from os import stat
import picamera
from picamera import PiCamera

def idparse(rocketID):
    print ("print parse RocketID",rocketID);
    cardlen = len(rocketID) #char length of current scanned card
    deflen = 42 #length card should be with no errors
    rocketnumber="R"
    if cardlen == deflen: #error check if card is defauld length

        for i in range(2,deflen): #start loop ater '%8'

            if rocketID[i] != '?': #grabs characters until sees the first '?' then breaks loop
                rocketnumber += rocketID[i]
                
            else:
                break
    else:
        rocketnumber = "R00000000"
        GPIO.output(20,GPIO.LOW)
        #GPIO.output(16,GPIO.HIGH)# this will be if you want the reference LED to turn red for errors
        #time.sleep(2.5)
        #GPIO.output(16,GPIO.LOW)
        print ("Error on read");
        GPIO.output(20,GPIO.HIGH)

    print(rocketnumber)
    return rocketnumber; 


def filetransfer(rocketInfo):
    
    # Open a file
    file = open("/home/pi/CAP/CAPid.txt", "a")
    file.write(rocketInfo);
    file.write('\n');
    
    # Close opened file
    file.close()
    print ("file transfer")
    return; 


def takePIC (picname):
    
    with picamera.PiCamera() as camera:
        camera.resolution = (1024, 768)
        #camera.start_preview() #this will allow for a preview of the picture if needed 
        #If you need a delay in Camera picture time
        #time.sleep(.5)  #this will be a delay in seconds
        #print ("picture taken");
        camera.vflip = True
        directory = '/home/pi/CAP/CAPpic'
        if not os.path.exists(directory):
            os.makedirs(directory)
            os.chmod(directory, 0o777)
        camera.capture('/home/pi/CAP/CAPpic/%s' %picname)

            
            
    return;

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#sets the LED's ready for future functions
GPIO.setup(16,GPIO.OUT)
GPIO.setup(20,GPIO.OUT)
GPIO.setup(21,GPIO.OUT)
GPIO.output(21,GPIO.HIGH)
time.sleep(2)
GPIO.output(21,GPIO.LOW)
GPIO.output(20,GPIO.HIGH)
#print ("program is starting for user input");
#test output for program running 

while True:

    print ("enter rocketid")
    rocketID = input("enter ROCKET-ID: ");
    
    if rocketID == "end":  
        break

    GPIO.output(20,GPIO.LOW)
    parseID  = idparse(rocketID)
    rocketID = parseID
    
    if rocketID == "R00000000":
        GPIO.output(16,GPIO.HIGH)# this will be if you want the reference LED to turn red for errors
        time.sleep(2.5)
        GPIO.output(16,GPIO.LOW)

    print ('rocketID =', rocketID)
    date = time.strftime("%Y-%m-%d")
    stime = time.strftime("%H:%M:%S")
    device = "1"
    fileinput = ","
    test = "-"
    seq2 = (rocketID, date, stime, device);
    picname = test.join(seq2) + ".jpg"
    seq1 = (rocketID, date, stime, device, picname);
    takePIC(picname)
    GPIO.output(20,GPIO.HIGH)
    filetransfer(fileinput.join(seq1))
     

GPIO.output(20,GPIO.LOW)


