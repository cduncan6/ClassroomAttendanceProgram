-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2016 at 03:01 AM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--
CREATE DATABASE IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `mydb`;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `DeviceNum` int(11) NOT NULL,
  `Date_` date NOT NULL,
  `Time_` time DEFAULT NULL,
  `RocketNum` varchar(45) NOT NULL,
  `Image` blob,
  `Comments` varchar(250) DEFAULT NULL,
  `idClass` int(11) DEFAULT NULL,
  `Status` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`DeviceNum`, `Date_`, `Time_`, `RocketNum`, `Image`, `Comments`, `idClass`, `Status`) VALUES
(1, '2016-11-21', '13:15:00', 'R00125431', NULL, '', 1, 'On Time'),
(1, '2016-11-21', '12:50:00', 'R00125432', NULL, '', 1, 'On Time'),
(1, '2016-11-21', '13:16:00', 'R00125433', NULL, '', 1, 'Tardy'),
(1, '2016-11-21', '14:30:00', 'R00125431', NULL, '', 2, 'On Time'),
(1, '2016-11-29', '15:00:59', 'R00961238', NULL, NULL, 3, 'On Time'),
(1, '2016-11-29', '15:01:00', 'R00951234', NULL, NULL, 3, 'Tardy'),
(1, '2016-11-29', '14:35:00', 'R00125431', NULL, NULL, 3, 'On Time'),
(1, '2016-11-29', '15:01:00', 'R00125432', NULL, NULL, 3, 'Tardy'),
(1, '2016-11-29', '15:00:00', 'R00125433', NULL, NULL, 3, 'On Time'),
(1, '2016-12-01', '14:45:00', 'R00125431', NULL, NULL, 3, 'On Time'),
(1, '2016-12-01', '15:05:00', 'R00125432', NULL, NULL, 3, 'Tardy'),
(1, '2016-12-01', '14:30:00', 'R00125433', NULL, NULL, 3, 'On Time'),
(1, '2016-12-06', NULL, 'R00961238', NULL, NULL, 3, 'Class Canceled'),
(1, '2016-12-06', NULL, 'R00951234', NULL, NULL, 3, 'Class Canceled'),
(1, '2016-12-06', NULL, 'R00125431', NULL, NULL, 3, 'Class Canceled'),
(1, '2016-12-06', NULL, 'R00125432', NULL, NULL, 3, 'Class Canceled'),
(1, '2016-12-06', NULL, 'R00125433', NULL, NULL, 3, 'Class Canceled'),
(1, '2016-12-05', NULL, 'R00125431', NULL, '', 1, 'Class Canceled'),
(1, '2016-12-05', NULL, 'R00125432', NULL, '', 1, 'Class Canceled'),
(1, '2016-12-05', NULL, 'R00125433', NULL, '', 1, 'Class Canceled');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

DROP TABLE IF EXISTS `class`;
CREATE TABLE `class` (
  `idClass` int(11) NOT NULL,
  `CRN` int(11) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Semester` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Year` int(11) NOT NULL,
  `Location_One` varchar(45) NOT NULL,
  `Location_Two` varchar(45) NOT NULL,
  `TeacherRocketNum` varchar(45) NOT NULL,
  `Days` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `Start_Time` time NOT NULL,
  `End_Time` time NOT NULL,
  `Tardy_Time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`idClass`, `CRN`, `Name`, `Semester`, `Year`, `Location_One`, `Location_Two`, `TeacherRocketNum`, `Days`, `Start_Time`, `End_Time`, `Tardy_Time`) VALUES
(1, 12345, 'CSET 2300', 'Fall 2016', 2016, 'NE 2300', '', 'R12345678', 'MWF', '13:00:00', '14:00:00', '13:16:00'),
(2, 67899, 'CSET 1300', 'Fall 2016', 2016, 'NE 2300', '', 'R12345678', 'MWF', '14:40:00', '16:00:00', '15:01:00'),
(3, 5215, 'CSET 4600', 'Fall 2016', 2016, 'NE 2300', '', 'R12345678', 'TTH', '14:40:00', '16:00:00', '15:01:00');

-- --------------------------------------------------------

--
-- Table structure for table `device`
--

DROP TABLE IF EXISTS `device`;
CREATE TABLE `device` (
  `DeviceID` int(11) NOT NULL,
  `Location` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `device`
--

INSERT INTO `device` (`DeviceID`, `Location`) VALUES
(1, 'NE 2300');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `RocketNum` varchar(25) NOT NULL,
  `Name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`RocketNum`, `Name`) VALUES
('R00125431', 'Trey'),
('R00125432', 'Mario'),
('R00125433', 'Steven'),
('R00951234', 'Jim Smith'),
('R00961238', 'Cody Duncan');

-- --------------------------------------------------------

--
-- Table structure for table `studentclass`
--

DROP TABLE IF EXISTS `studentclass`;
CREATE TABLE `studentclass` (
  `RocketNum` varchar(25) NOT NULL,
  `idClass` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `studentclass`
--

INSERT INTO `studentclass` (`RocketNum`, `idClass`) VALUES
('R00125431', 1),
('R00125432', 1),
('R00125433', 1),
('R00125431', 2),
('R00961238', 3),
('R00951234', 3),
('R00125431', 3),
('R00125432', 3),
('R00125433', 3);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `RocketNum` varchar(25) NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`RocketNum`, `Name`, `Password`) VALUES
('R12345678', 'Mario', 'a94a8fe5ccb19ba61c4c0873d391e987982fbbd3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`idClass`);

--
-- Indexes for table `device`
--
ALTER TABLE `device`
  ADD PRIMARY KEY (`DeviceID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`RocketNum`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`RocketNum`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `idClass` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
